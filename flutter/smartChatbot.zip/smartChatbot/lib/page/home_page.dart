import 'dart:convert';
import 'package:avatar_glow/avatar_glow.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smarty_chatbot/api/speech_api.dart';
import 'package:ibm_watson_assistant/ibm_watson_assistant.dart';
import 'package:flutter_tts/flutter_tts.dart';

class HomePage extends StatefulWidget {

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var tts = FlutterTts();
  Home() {
    tts.setLanguage('en');
    tts.setPitch(0);
    tts.setSpeechRate(0.5);
  }

  String text = '';//to store the user's speech as text
  String robotresponse = '';// store the robot's response as text
  String res = '';// stores the encoded robot response
  String robot = 'assets/images/full.png';// store the displayed image path
  String category = '';// stores the intent of the user's speech
  bool isListening = false;// store boolean value weather the bot is listening or not
  final String title= 'Smarty';// the app title

  final auth = IbmWatsonAssistantAuth(// the chatbot's credentials
    assistantId: '9803e616-d3cb-42b6-961b-5f8cb37b3dd5',
    url: 'https://api.eu-gb.assistant.watson.cloud.ibm.com/instances/72493d59-0b84-42ed-a819-db2539010eab/v2/assistants/9803e616-d3cb-42b6-961b-5f8cb37b3dd5/sessions',
    apikey: 'U-jHQuZAHxgk8x1kZwnvq8Cq2wsTdrj2-NryZE8GSoy9',
  );

  Future<void> _getChatbotResponse() async {

    try {
      final bot = IbmWatsonAssistant(auth);
      final sessionId = await bot.createSession();
      var botRes = await bot.sendInput(text, sessionId: sessionId);

      res=json.encode(botRes);
      Map<String, dynamic> user = jsonDecode(res);//convert the whole response into a map
      category=user['output']['intents'][0]['intent'];//get the intent of the text

      if (user['output']['generic'][0]['text'] == null){//if the bot doesn't have a response then throw an exception
        throw ('This is my first custom exception');
      }

      robotresponse=  botRes.responseText!;//get the robot response
      tts.speak(robotresponse);//convert robot response from text to audio

    } catch (e) {
      final bot = IbmWatsonAssistant(auth);
      final sessionId = await bot.createSession();
      var botRes = await bot.sendInput("ok", sessionId: sessionId);
      res=json.encode(botRes);
      Map<String, dynamic> user = jsonDecode(res);
      category=user['output']['intents'][0]['intent'];
      robotresponse=botRes.responseText!;
      tts.speak(robotresponse);
    }

    switch(category) {//display the accurate robot expression depending on the given intent

      case "anything": {robot = 'assets/images/confused.gif';}
      break;

      case "location": {robot = 'assets/images/locations.gif';}
      break;

      case "contactus": {robot = 'assets/images/contact.gif';}
      break;

      case "General_Negative_Feedback": {robot = 'assets/images/sad.gif';}
      break;

      case "General_Positive_Feedback": {robot = 'assets/images/love.gif';}
      break;

      case "General_Ending": {robot = 'assets/images/blush.gif';}
      break;

      case "robots": {robot = 'assets/images/robots.gif';}
      break;

      case "help": {robot = 'assets/images/help.gif';}
      break;

      case "aboutUS": {robot = 'assets/images/aboutus.gif';}
      break;

      case "clients": {robot = 'assets/images/clients.gif';}
      break;

      case "other": {robot = 'assets/images/confused.gif';}
      break;

      case "thanks": {robot = 'assets/images/love.gif';}
      break;

      case "who": {//this intent has multiple bot responses, each has a unique bot expression
        if(robotresponse.contains("compliment")){robot = 'assets/images/smarty.gif';}
        else{robot = 'assets/images/blush.gif';}}
      break;

      case "General_Human_or_Bot": {//this intent has multiple bot responses, each has a unique bot expression
        if(robotresponse.contains("peaceful")){robot = 'assets/images/innocent.gif';}
        else{robot = 'assets/images/proud.gif';}}
      break;

      case "achievements": {//this intent has multiple bot responses, each has a unique bot expression
        if(robotresponse.contains("Innovations")){robot = 'assets/images/achieve1.gif';}
        else{robot = 'assets/images/achieve2.gif';}}
      break;

      default: {robot = 'assets/images/talking.gif';}
      break;
    }
    text='';
    res='';
    robotresponse='';
    category='';
    setState(() {});//refresh the page

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(title),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(robot),
            fit: BoxFit.fill,
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: AvatarGlow(
        animate: isListening,
        endRadius: 75,
        glowColor: Theme.of(context).primaryColor,
        child: FloatingActionButton(
          child: Icon(isListening ? Icons.mic : Icons.mic_none, size: 36),
          onPressed: toggleRecording,
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  Future toggleRecording() => SpeechApi.toggleRecording(
        onResult: (text) => setState((){
          robot = 'assets/images/full.png';// if the bot is listening change his look to stay still
          setState(() {});//refresh the page
          this.text = text;
        } ),

        onListening: (isListening) {
          tts.stop();//stop talking if the user is currently talking
          setState(() => this.isListening = isListening);

          if (!isListening) {
            _getChatbotResponse();//if the user is done talking , go to this function and get the chatbot's response
            tts.setCompletionHandler(() {//after the audio is done refresh the page with different robot photo
              setState(() {robot = 'assets/images/looking.gif';});});
           }
        },
      );
}
